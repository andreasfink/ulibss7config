//
//  UMSS7ConfigSCCPNumberTranslation.h
//  ulibss7config
//
//  Created by Andreas Fink on 20.04.18.
//  Copyright © 2018 Andreas Fink. All rights reserved.
//

#import "UMSS7ConfigObject.h"

@interface UMSS7ConfigSCCPNumberTranslation : UMSS7ConfigObject
{
}

+ (NSString *)type;
- (NSString *)type;

@end
